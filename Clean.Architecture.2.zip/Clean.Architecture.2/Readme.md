## Run the docker compose

```bash
docker compose up --build
```

### Enter the URL in your browser

[http://localhost:8080/swagger/index.html](http://localhost:8080/swagger/index.html)


ctrl + c to stop your containers and after that just use the below command to release the resources:

```sh
$ docker compose down
```

