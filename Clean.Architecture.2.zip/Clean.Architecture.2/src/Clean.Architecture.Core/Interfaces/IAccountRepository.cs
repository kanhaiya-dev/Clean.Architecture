﻿using Clean.Architecture.Core.Entities.Buisness;

namespace Clean.Architecture.Core.Interfaces
{
    public interface IAccountRepository : IRepository<Account>
    {
    }
}
